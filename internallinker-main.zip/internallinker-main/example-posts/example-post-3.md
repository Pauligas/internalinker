---
date: 2021-06-14
title: Another another post
rootPage: /blog
sidebar: Blog
showTitle: true
hideAnchor: true
keywords: ["words"]
featuredImage: ../images/blog/series-b/series-b-baby.png
author: ["joe-martin"]
---

# Another slam dunk hit

A page all about being transparent. And some things about funnels. That and a funnel. Also, funnel - ok. What about funnel, yeah? And funnel; does that work?

Oh and you should see our other post on fundraising. Learn to fundraise there.

Take care!
