---
date: 2021-06-10
title: PostHog raises $15 million Series B for open source product analytics
rootPage: /blog
sidebar: Blog
showTitle: true
hideAnchor: true
keywords: ["fundraise", "fundraising"]
featuredImage: ../images/blog/series-b/series-b-baby.png
author: ["joe-martin"]
---

# A really cool page

This page is so awesome.

Here's some text. The opposite of opaque is transparent.

Here is more text. In fact, here is something about cancer and founder break up. Ok bye.

Oh and we should fundraise soon.

A pre-existing [funnels](funnels) link.

Ciao ciao.
